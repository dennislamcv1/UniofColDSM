# Point Estimates

View(Point_Estimates)

(xbar<-mean(Point_Estimates$Weight))
(sd<-sd(Point_Estimates$Weight))

(prop<-mean(Point_Estimates$Proportion))

(count<-mean(Point_Estimates$Count))
